const initialQuestion = "What symptoms are you experiencing today?";

const state = {
  turns: [{ speaker: "doctor", text: initialQuestion }],
  askedSymptoms: [],
  report: null,
  rules: [],
};

const chatLog = document.querySelector("#chatLog");
const form = document.querySelector("#intakeForm");
const input = document.querySelector("#patientInput");
const generateButton = document.querySelector("#generateButton");
const resetButton = document.querySelector("#resetButton");
const statusBadge = document.querySelector("#statusBadge");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  addTurn("patient", text);
  input.value = "";
  await continueIntake(false);
});

generateButton.addEventListener("click", async () => {
  await continueIntake(true);
});

resetButton.addEventListener("click", () => {
  state.turns = [{ speaker: "doctor", text: initialQuestion }];
  state.askedSymptoms = [];
  state.report = null;
  input.value = "";
  setStatus("Ready", "idle");
  render();
  input.focus();
});

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => activateTab(button.dataset.tab));
});

function addTurn(speaker, text) {
  state.turns.push({ speaker, text });
  renderChat();
}

async function continueIntake(finalize) {
  setStatus("Analyzing", "busy");
  try {
    const response = await fetch("/api/intake", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        turns: state.turns,
        asked_symptoms: state.askedSymptoms,
        finalize,
      }),
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Request failed");

    state.askedSymptoms = payload.asked_symptoms || state.askedSymptoms;
    if (payload.next_question) {
      addTurn("doctor", payload.next_question);
      setStatus("Follow-up", "idle");
      return;
    }

    state.report = payload.report;
    setStatus(statusTextForReport(payload.report), payload.report.overall_confidence === "low" ? "alert" : "idle");
    renderReport();
  } catch (error) {
    setStatus("Error", "alert");
    renderError(error.message);
  }
}

function render() {
  renderChat();
  renderReport();
}

function renderChat() {
  chatLog.innerHTML = "";
  state.turns.forEach((turn) => {
    const message = document.createElement("div");
    message.className = `message ${turn.speaker === "patient" ? "patient" : "doctor"}`;
    message.innerHTML = `
      <strong>${turn.speaker === "patient" ? "Patient" : "CERTINOTE"}</strong>
      <p>${escapeHtml(turn.text)}</p>
    `;
    chatLog.appendChild(message);
  });
  chatLog.scrollTop = chatLog.scrollHeight;
}

function renderReport() {
  const report = state.report;
  if (!report) {
    document.querySelector("#confidenceLabel").textContent = "Awaiting input";
    document.querySelector("#conditionSummary").textContent = "Not evaluated";
    document.querySelector("#safetySummary").textContent = "No report yet";
    document.querySelector("#soapTab").innerHTML = `<p class="empty-state">Answer the intake questions, then generate the note.</p>`;
    document.querySelector("#evidenceTab").innerHTML = `<p class="empty-state">Evidence checks will appear here.</p>`;
    document.querySelector("#billingTab").innerHTML = `<p class="empty-state">Billing review suggestions will appear here.</p>`;
    renderRules();
    document.querySelector("#jsonTab").textContent = "";
    return;
  }

  document.querySelector("#confidenceLabel").textContent = `Confidence: ${report.overall_confidence}`;
  document.querySelector("#conditionSummary").textContent = conditionSummary(report);
  document.querySelector("#safetySummary").textContent = report.review_flags.join(", ");
  renderSoap(report);
  renderEvidence(report);
  renderBilling(report);
  renderRules();
  document.querySelector("#jsonTab").textContent = JSON.stringify(report, null, 2);
}

function renderSoap(report) {
  const sections = report.soap_note.sections;
  const names = [
    ["subjective", "Subjective"],
    ["objective", "Objective"],
    ["assessment", "Assessment"],
    ["plan", "Plan"],
  ];
  document.querySelector("#soapTab").innerHTML = names.map(([key, label]) => `
    <article class="soap-section">
      <h3>${label}</h3>
      <p>${escapeHtml(sections[key].text)}</p>
      <div class="flag-list">
        <span class="flag">${sections[key].confidence}</span>
        ${sections[key].review_required ? `<span class="flag">review required</span>` : ""}
      </div>
    </article>
  `).join("");
}

function renderEvidence(report) {
  const checks = report.verification_report.claim_checks;
  document.querySelector("#evidenceTab").innerHTML = checks.map((check) => `
    <article class="evidence-row">
      <h3>${escapeHtml(check.claim)}</h3>
      <span class="claim-status ${check.support_status}">${check.support_status}</span>
      <p>${escapeHtml(check.explanation)}</p>
      <p>Evidence turns: ${check.evidence_turn_ids.length ? check.evidence_turn_ids.join(", ") : "none"}</p>
    </article>
  `).join("");
}

function renderBilling(report) {
  document.querySelector("#billingTab").innerHTML = report.billing_suggestions.map((item) => `
    <article class="billing-row">
      <h3>${escapeHtml(item.code)}</h3>
      <p>${escapeHtml(item.description)}</p>
      <div class="flag-list">
        <span class="flag">${item.confidence}</span>
        <span class="flag">human review</span>
      </div>
    </article>
  `).join("");
}

function renderRules() {
  const rulesTab = document.querySelector("#rulesTab");
  if (!state.rules.length) {
    rulesTab.innerHTML = `<p class="empty-state">Condition rules are loading.</p>`;
    return;
  }

  rulesTab.innerHTML = state.rules.map((rule) => {
    const required = rule.required_symptoms.map((symptom) => symptom.name).join(", ");
    const supporting = rule.supporting_symptoms.length
      ? rule.supporting_symptoms.map((symptom) => symptom.name).join(", ")
      : "none";
    return `
      <article class="rule-row">
        <h3>${escapeHtml(rule.condition_name)}</h3>
        <p>${escapeHtml(rule.condition_id)}</p>
        <div class="rule-grid">
          <div>
            <strong>Required</strong>
            <span>${escapeHtml(required)}</span>
          </div>
          <div>
            <strong>Supporting</strong>
            <span>${escapeHtml(supporting)}</span>
          </div>
        </div>
      </article>
    `;
  }).join("");
}

function renderError(message) {
  document.querySelector("#soapTab").innerHTML = `<p class="empty-state">${escapeHtml(message)}</p>`;
}

function activateTab(name) {
  document.querySelectorAll(".tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.tab === name);
  });
  document.querySelectorAll(".tab-panel").forEach((panel) => {
    panel.classList.remove("active");
  });
  document.querySelector(`#${name}Tab`).classList.add("active");
}

function conditionSummary(report) {
  if (!report.condition_matches.length) return "Insufficient evidence";
  return report.condition_matches.map((match) => match.condition_name).join(", ");
}

function statusTextForReport(report) {
  return report.overall_confidence === "low" ? "Needs evidence" : "Report ready";
}

function setStatus(text, mode) {
  statusBadge.textContent = text;
  statusBadge.className = `status-badge ${mode}`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function loadRules() {
  try {
    const response = await fetch("/api/rules");
    const payload = await response.json();
    state.rules = payload.conditions || [];
    renderRules();
  } catch (error) {
    document.querySelector("#rulesTab").innerHTML = `<p class="empty-state">Unable to load rules.</p>`;
  }
}

render();
loadRules();
