# CERTINOTE

CERTINOTE is an ambient clinical scribe prototype that turns doctor-patient conversations into SOAP notes, verifies each generated claim against the source transcript, and suggests billing codes for human review.

The project goal is not just to generate a note. The goal is to make every generated section traceable, reviewable, and honest about uncertainty.

## Core Workflow

1. Ingest a doctor-patient transcript or live text conversation.
2. Clean and normalize the conversation.
3. Extract patient-reported symptoms.
4. Match symptoms against transparent condition rules.
5. Return "insufficient evidence" when no full rule matches.
6. Generate a structured SOAP note.
7. Cross-check the note against the transcript.
8. Suggest demo billing concepts only when evidence exists.
9. Show confidence and uncertainty per section.

## Why This Matters

Most student healthcare AI demos stop at:

```text
Transcript -> AI-generated clinical note
```

This project adds the production-minded layer:

```text
Transcript -> SOAP note -> evidence verification -> uncertainty flags -> human review
```

That directly addresses trust, governance, and safety concerns in healthcare AI.

## MVP Features

- Run a guided live patient intake from the terminal.
- Generate a SOAP note with Subjective, Objective, Assessment, and Plan sections.
- Verify each SOAP claim against transcript evidence.
- Mark claims as supported, unsupported, contradicted, or uncertain.
- Detect important transcript details missing from the generated note.
- Suggest possible billing codes for review, never final billing decisions.
- Display confidence labels for each SOAP section.
- Capture a live text conversation from the terminal.
- Match only patient or caregiver-reported symptoms, not clinician prompts.

## Safety Positioning

This is a portfolio and research prototype. It is not intended for clinical use.

- No real patient data should be used.
- Use synthetic, public, or properly de-identified transcripts only.
- All generated medical content requires clinician review.
- Billing suggestions are informational and require certified coder review.
- The system should prefer "insufficient evidence" over guessing.

## Suggested Stack

- Backend: Python, FastAPI, Pydantic
- LLM orchestration: simple function pipeline first, LangGraph later if needed
- Frontend: React or Next.js
- Storage: SQLite for MVP
- Evaluation: pytest plus JSON evaluation reports
- Optional later: audio transcription with Whisper or a hosted ASR API

## Repository Structure

```text
docs/
  ROADMAP.md
  WORKFLOW.md
schemas/
  transcript.schema.json
  soap_note.schema.json
  verification_report.schema.json
data/
  disease_rules/
  sample_transcripts/
certinote/
  pipeline.py
scripts/
  patient_intake.py
  live_conversation.py
  run_pipeline.py
  serve_web.py
web/
  index.html
  styles.css
  app.js
```

## Run The Web App

Start the local CERTINOTE web demo:

```bash
python3 scripts/serve_web.py --port 8000
```

Then open:

```text
http://127.0.0.1:8000
```

The web app provides a guided patient intake, asks follow-up questions based on matched symptom rules, and displays the SOAP note, evidence checks, review flags, and billing review suggestions.

The Rules tab shows the configured symptom requirements for each prototype condition, so the matching behavior is inspectable instead of hidden.

## Recommended Demo Workflow

Use the guided patient intake when you want CERTINOTE to ask follow-up questions and build the note from a live conversation instead of a prewritten transcript:

```bash
python3 scripts/patient_intake.py
```

Example interaction:

```text
certinote: What symptoms are you experiencing today?
> I have a sore throat and fever.
certinote: Do you have any cough?
> No cough.
```

CERTINOTE then writes:

```text
reports/patient-intake.report.json
reports/patient-intake.transcript.json
```

The captured transcript is created from the live interaction. It is not loaded from a synthetic transcript file.

## Run The First Pipeline

The file-based pipeline is useful for development tests. It loads a transcript, extracts symptoms, matches them against configured condition rules, generates a SOAP note, verifies claims against transcript evidence, adds review flags, and writes a final JSON report.

Run it with:

```bash
python3 scripts/run_pipeline.py
```

The report is written to:

```text
reports/sample-001.report.json
```

You can also pass your own transcript and output path:

```bash
python3 scripts/run_pipeline.py --transcript data/sample_transcripts/sample-001.json --output reports/my-report.json
```

To prove the safety behavior, run the insufficient-evidence example:

```bash
python3 scripts/run_pipeline.py --transcript data/sample_transcripts/sample-002-insufficient.json --output reports/sample-002-insufficient.report.json
```

That report should include:

```text
INSUFFICIENT_EVIDENCE
```

## Run A Live Text Conversation

Use this when you want to type a real-time conversation turn by turn:

```bash
python3 scripts/live_conversation.py
```

Enter turns like:

```text
doctor: What brings you in today?
patient: I have a sore throat and fever.
doctor: Any cough?
patient: No cough.
```

Press Enter on a blank line to finish. CERTINOTE writes the final report to:

```text
reports/live-conversation.report.json
```

## Condition Rules

The demo condition rules live here:

```text
data/disease_rules/demo_conditions.json
```

A condition is suggested only when all required symptoms for that rule are found in patient or caregiver turns. Otherwise, CERTINOTE returns "insufficient evidence" instead of guessing.

## Run Tests

Run the regression tests with:

```bash
python3 -m unittest discover -s tests
```

The tests cover:

- matching when all required symptoms are present,
- returning insufficient evidence when symptoms are incomplete,
- ignoring clinician prompts as symptom evidence,
- handling negated symptoms such as "I don't have a fever",
- asking relevant guided-intake follow-up questions.

## Demo Statements

Try these patient statements in the web app:

```text
I have a sore throat and fever.
I have fever, cough, and body aches.
I have a runny nose, stuffy nose, and sore throat.
I have sneezing, itchy eyes, and a runny nose.
I have facial pressure, a stuffy nose, and a headache.
I have headache, nausea, and light sensitivity.
I have burning when urinating and I am peeing often.
I have diarrhea, vomiting, and stomach cramps.
I have heartburn and acid coming up after eating.
I have wheezing, shortness of breath, and chest tightness.
I have red eyes, sticky eye discharge, and gritty irritation.
I have ear pain, muffled hearing, and fever.
```

For the safety demo:

```text
I feel tired.
```

Then answer follow-ups negatively. CERTINOTE should return `INSUFFICIENT_EVIDENCE`.

## First Milestone

Given one transcript, produce a SOAP note where every claim has:

- evidence from the transcript,
- a support status,
- a confidence label,
- and a review flag when needed.
