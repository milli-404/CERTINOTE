from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from certinote.intake import build_follow_up_questions, build_transcript, transcript_to_dict
from certinote.pipeline import TranscriptTurn, extract_symptom_findings, load_condition_rules, match_conditions, run_pipeline_for_transcript


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a guided CERTINOTE patient intake.")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("reports/patient-intake.report.json"),
        help="Path where the final report JSON should be written.",
    )
    parser.add_argument(
        "--transcript-output",
        type=Path,
        default=Path("reports/patient-intake.transcript.json"),
        help="Path where the captured live transcript JSON should be written.",
    )
    parser.add_argument(
        "--rules",
        type=Path,
        default=Path("data/disease_rules/demo_conditions.json"),
        help="Path to the symptom-to-condition rules JSON file.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rules = load_condition_rules(args.rules)
    turns: list[TranscriptTurn] = []

    print("CERTINOTE guided intake")
    print("This is a prototype intake assistant, not medical advice. Answer as the patient.")

    ask(turns, "What symptoms are you experiencing today?")
    symptoms = read_answer()
    add_patient_turn(turns, symptoms)

    asked_symptoms: set[str] = set()
    for question in build_follow_up_questions(turns, rules, asked_symptoms):
        ask(turns, question)
        answer = read_answer()
        add_patient_turn(turns, answer)

    transcript = build_transcript(turns)
    symptom_findings = extract_symptom_findings(transcript, rules)
    condition_matches = match_conditions(symptom_findings, rules)

    if not condition_matches:
        for question in build_follow_up_questions(turns, rules, asked_symptoms):
            ask(turns, question)
            answer = read_answer()
            add_patient_turn(turns, answer)

    transcript = build_transcript(turns)
    report = run_pipeline_for_transcript(transcript, rules_path=args.rules)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.transcript_output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    args.transcript_output.write_text(json.dumps(transcript_to_dict(transcript), indent=2) + "\n", encoding="utf-8")

    print(f"Wrote CERTINOTE report to {args.output}")
    print(f"Wrote captured transcript to {args.transcript_output}")
    print(f"Condition matches: {format_condition_matches(report)}")
    print(f"Overall confidence: {report['overall_confidence']}")
    print(f"Review flags: {', '.join(report['review_flags'])}")


def read_answer() -> str:
    try:
        return input("> ").strip()
    except EOFError:
        return ""


def ask(turns: list[TranscriptTurn], text: str) -> None:
    print(f"certinote: {text}")
    turns.append(TranscriptTurn(turn_id=f"t{len(turns) + 1}", speaker="doctor", text=text))


def add_patient_turn(turns: list[TranscriptTurn], text: str) -> None:
    turns.append(TranscriptTurn(turn_id=f"t{len(turns) + 1}", speaker="patient", text=text))


def format_condition_matches(report: dict) -> str:
    matches = report["condition_matches"]
    if not matches:
        return "insufficient evidence"
    return ", ".join(match["condition_name"] for match in matches)


if __name__ == "__main__":
    main()
