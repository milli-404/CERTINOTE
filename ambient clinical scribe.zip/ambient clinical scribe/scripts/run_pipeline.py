from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from certinote.pipeline import run_pipeline


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the CERTINOTE demo pipeline.")
    parser.add_argument(
        "--transcript",
        type=Path,
        default=Path("data/sample_transcripts/sample-001.json"),
        help="Path to a transcript JSON file.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("reports/sample-001.report.json"),
        help="Path where the final report JSON should be written.",
    )
    parser.add_argument(
        "--rules",
        type=Path,
        default=Path("data/disease_rules/demo_conditions.json"),
        help="Path to the symptom-to-condition rules JSON file.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    report = run_pipeline(args.transcript, rules_path=args.rules)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    print(f"Wrote CERTINOTE report to {args.output}")
    print(f"Overall confidence: {report['overall_confidence']}")
    print(f"Review flags: {', '.join(report['review_flags'])}")


if __name__ == "__main__":
    main()
