from __future__ import annotations

import argparse
import json
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from certinote.intake import build_follow_up_questions, build_transcript, transcript_to_dict, turns_from_payload
from certinote.pipeline import load_condition_rules, run_pipeline_for_transcript


WEB_ROOT = PROJECT_ROOT / "web"
RULES_PATH = PROJECT_ROOT / "data" / "disease_rules" / "demo_conditions.json"


class CertinoteHandler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            self.write_json({"ok": True})
            return
        if parsed.path == "/api/rules":
            self.write_json({"conditions": load_condition_rules(RULES_PATH)})
            return

        path = "/index.html" if parsed.path == "/" else parsed.path
        file_path = (WEB_ROOT / path.lstrip("/")).resolve()
        if not str(file_path).startswith(str(WEB_ROOT.resolve())) or not file_path.exists():
            self.send_error(404)
            return

        content_type = content_type_for(file_path)
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/intake":
            self.send_error(404)
            return

        try:
            payload = self.read_json()
            self.write_json(handle_intake(payload))
        except ValueError as error:
            self.write_json({"error": str(error)}, status=400)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def write_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: object) -> None:
        return


def handle_intake(payload: dict) -> dict:
    raw_turns = payload.get("turns", [])
    if not isinstance(raw_turns, list):
        raise ValueError("turns must be a list")

    turns = turns_from_payload(raw_turns)
    asked_symptoms = set(payload.get("asked_symptoms", []))
    finalize = bool(payload.get("finalize", False))
    rules = load_condition_rules(RULES_PATH)

    if not finalize:
        questions = build_follow_up_questions(turns, rules, asked_symptoms)
        if questions:
            return {
                "next_question": questions[0],
                "asked_symptoms": sorted(asked_symptoms),
            }

    transcript = build_transcript(turns)
    report = run_pipeline_for_transcript(transcript, rules_path=RULES_PATH)
    return {
        "next_question": None,
        "asked_symptoms": sorted(asked_symptoms),
        "transcript": transcript_to_dict(transcript),
        "report": report,
    }


def content_type_for(path: Path) -> str:
    suffix = path.suffix
    if suffix == ".html":
        return "text/html; charset=utf-8"
    if suffix == ".css":
        return "text/css; charset=utf-8"
    if suffix == ".js":
        return "text/javascript; charset=utf-8"
    return "application/octet-stream"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Serve the CERTINOTE web demo.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    server = ThreadingHTTPServer((args.host, args.port), CertinoteHandler)
    print(f"CERTINOTE web app running at http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping CERTINOTE web app")


if __name__ == "__main__":
    main()
