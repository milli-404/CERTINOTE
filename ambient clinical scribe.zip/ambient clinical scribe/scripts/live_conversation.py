from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from certinote.pipeline import Transcript, TranscriptTurn, run_pipeline_for_transcript


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Capture a live text conversation and run CERTINOTE.")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("reports/live-conversation.report.json"),
        help="Path where the final report JSON should be written.",
    )
    parser.add_argument(
        "--rules",
        type=Path,
        default=Path("data/disease_rules/demo_conditions.json"),
        help="Path to the symptom-to-condition rules JSON file.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    print("CERTINOTE live text conversation")
    print("Type each turn as 'doctor: ...' or 'patient: ...'. Press Enter on a blank line to finish.")

    turns = []
    turn_number = 1
    while True:
        try:
            raw_line = input("> ").strip()
        except EOFError:
            break

        if not raw_line:
            break

        speaker, text = parse_turn(raw_line)
        turns.append(TranscriptTurn(turn_id=f"t{turn_number}", speaker=speaker, text=text))
        turn_number += 1

    if not turns:
        print("No conversation turns were entered.")
        return

    transcript = Transcript(
        transcript_id=f"live-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
        source_type="demo",
        metadata={"input_mode": "live_text"},
        turns=turns,
    )
    report = run_pipeline_for_transcript(transcript, rules_path=args.rules)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    print(f"Wrote CERTINOTE report to {args.output}")
    print(f"Condition matches: {format_condition_matches(report)}")
    print(f"Overall confidence: {report['overall_confidence']}")
    print(f"Review flags: {', '.join(report['review_flags'])}")


def parse_turn(raw_line: str) -> tuple[str, str]:
    if ":" not in raw_line:
        return "patient", raw_line

    raw_speaker, text = raw_line.split(":", 1)
    speaker = raw_speaker.strip().lower()
    text = text.strip()
    if speaker not in {"doctor", "patient", "caregiver", "nurse", "other"}:
        speaker = "other"
    return speaker, text


def format_condition_matches(report: dict) -> str:
    matches = report["condition_matches"]
    if not matches:
        return "insufficient evidence"
    return ", ".join(match["condition_name"] for match in matches)


if __name__ == "__main__":
    main()
