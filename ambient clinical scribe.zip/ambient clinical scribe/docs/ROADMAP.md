# Project Roadmap

This roadmap is designed for a strong portfolio build that can be completed in stages.

## Phase 0: Project Definition

Goal: Define the product clearly before writing app code.

Deliverables:

- Project README
- Workflow diagram
- Input and output schemas
- One synthetic transcript
- One target example output

Success criteria:

- A reviewer can understand what the project does in under one minute.
- The safety-net idea is visible immediately.

## Phase 1: Transcript-To-SOAP MVP

Goal: Convert a transcript into a structured SOAP note.

Inputs:

- A plain text or JSON transcript
- Speaker labels such as Doctor, Patient, Caregiver

Outputs:

- Subjective section
- Objective section
- Assessment section
- Plan section
- Initial confidence per section

Implementation tasks:

- Create transcript loader.
- Normalize speaker turns.
- Define SOAP note JSON schema.
- Build first SOAP generation prompt or local mock generator.
- Validate output with Pydantic.

Success criteria:

- The system can process at least 5 sample transcripts.
- SOAP output is valid JSON.
- Empty or missing clinical information is explicitly marked as not documented.

## Phase 2: Evidence Verification Agent

Goal: Check generated SOAP claims against the original transcript.

Verification statuses:

- supported
- partially_supported
- unsupported
- contradicted
- uncertain

Implementation tasks:

- Split SOAP sections into atomic claims.
- For each claim, retrieve relevant transcript evidence.
- Ask a verifier to judge support status.
- Return evidence quotes or turn IDs.
- Flag claims without evidence.
- Detect important transcript facts missing from the SOAP note.

Success criteria:

- Every generated claim has a support status.
- Unsupported claims are visible in the UI or report.
- Missing details are listed separately.

## Phase 3: Confidence And Uncertainty Layer

Goal: Make uncertainty obvious and useful.

Confidence inputs:

- Number of supported claims
- Number of uncertain or unsupported claims
- Missing critical facts
- Presence of objective exam data
- Presence of diagnosis or treatment ambiguity

Implementation tasks:

- Create a confidence scoring function.
- Assign high, medium, or low confidence per SOAP section.
- Generate review reasons.
- Add a final "needs clinician review" flag.

Success criteria:

- The system is conservative.
- Sections with weak evidence get lower confidence.
- The output never hides uncertainty.

## Phase 4: Billing Code Suggestion Agent

Goal: Suggest possible codes with evidence and disclaimers.

Scope:

- Diagnosis suggestions: ICD-10-CM-style concepts
- Procedure or visit suggestions: CPT/HCPCS-style concepts
- Human review required

Implementation tasks:

- Start with a small curated demo code map.
- Extract symptoms, diagnoses, visit type, and procedures.
- Suggest possible codes only when evidence exists.
- Return "insufficient information" when unsure.
- Include evidence and rationale for every suggestion.

Success criteria:

- No code is suggested without a supporting transcript detail.
- Billing output is clearly labeled as non-final.

## Phase 5: Dashboard

Goal: Make the safety net easy to understand visually.

Recommended layout:

- Left: original transcript
- Middle: generated SOAP note
- Right: safety report and billing suggestions

Features:

- Claim status badges
- Evidence links back to transcript turns
- Confidence labels
- Missing detail warnings
- Export JSON

Success criteria:

- A recruiter can understand the safety layer without reading the code.
- The interface makes review faster, not more confusing.

## Phase 6: Evaluation

Goal: Prove the project works beyond a single demo.

Metrics:

- SOAP completeness
- Hallucination rate
- Missing-detail rate
- Evidence coverage
- Confidence calibration
- Billing suggestion precision

Implementation tasks:

- Create test transcripts with known expected facts.
- Add regression tests for hallucination detection.
- Create an evaluation report across sample cases.

Success criteria:

- The project can show measurable improvement from baseline note generation.
- The README includes a small results table.

## Phase 7: Portfolio Polish

Goal: Make the project presentation-ready.

Deliverables:

- Demo video
- Architecture diagram
- Evaluation report
- Clear limitations section
- Setup instructions
- Sample outputs

Success criteria:

- The project reads as a thoughtful healthcare AI system, not a generic chatbot.

