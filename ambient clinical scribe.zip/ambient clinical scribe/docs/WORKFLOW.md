# End-To-End Workflow

## High-Level Pipeline

```text
Transcript
  -> Transcript Preprocessor
  -> SOAP Note Agent
  -> Claim Extractor
  -> Evidence Verification Agent
  -> Missing Detail Detector
  -> Billing Suggestion Agent
  -> Confidence And Review Layer
  -> Final Report
```

## Step 1: Transcript Input

The first version accepts text or JSON transcripts.

Each transcript should include:

- transcript ID
- source type
- speaker turns
- optional metadata such as visit type

Example:

```json
{
  "id": "sample-001",
  "source_type": "synthetic",
  "turns": [
    {
      "turn_id": "t1",
      "speaker": "doctor",
      "text": "What brings you in today?"
    },
    {
      "turn_id": "t2",
      "speaker": "patient",
      "text": "I have had a sore throat and fever for three days."
    }
  ]
}
```

## Step 2: Preprocessing

The preprocessor cleans the transcript without changing clinical meaning.

Responsibilities:

- Normalize speaker labels.
- Remove filler only when safe.
- Preserve negations such as "no chest pain."
- Preserve time expressions such as "for three days."
- Assign stable turn IDs.

Rule: never delete clinically meaningful uncertainty or negation.

## Step 3: SOAP Note Generation

The SOAP agent creates a structured note.

Required behavior:

- Use only information found in the transcript.
- Write "not documented" when information is absent.
- Avoid diagnosing beyond the evidence.
- Keep each claim clear enough to verify later.

Output sections:

- Subjective
- Objective
- Assessment
- Plan

## Step 4: Claim Extraction

The claim extractor turns the SOAP note into small checkable claims.

Example SOAP sentence:

```text
Patient reports sore throat and fever for three days and denies cough.
```

Extracted claims:

```text
1. Patient reports sore throat.
2. Patient reports fever.
3. Symptoms have lasted three days.
4. Patient denies cough.
```

Smaller claims are easier to verify and debug.

## Step 5: Evidence Verification

The verifier checks every claim against the transcript.

For each claim, it returns:

- support status
- transcript evidence
- missing evidence
- explanation
- confidence score

Support statuses:

- supported: clearly present in transcript
- partially_supported: partly present, but incomplete
- unsupported: not found in transcript
- contradicted: transcript says the opposite
- uncertain: ambiguous or hard to judge

## Step 6: Missing Detail Detection

This step finds important facts that were in the transcript but absent from the SOAP note.

Examples:

- medication allergies
- red-flag symptoms
- duration of symptoms
- denied symptoms
- current medications
- follow-up instructions

The missing-detail detector should be conservative. It should focus on clinically meaningful omissions.

## Step 7: Billing Suggestions

The billing agent suggests possible codes for review.

Required behavior:

- Include evidence for each suggestion.
- Explain why the code might apply.
- Mark uncertain codes as uncertain.
- Say "insufficient information" instead of guessing.
- Make clear that a human coder must review.

## Step 8: Confidence And Review Layer

The final layer summarizes risk.

Confidence should decrease when:

- a section has unsupported claims
- objective exam data is missing
- assessment is speculative
- plan includes actions not discussed in transcript
- important details were omitted

Recommended confidence labels:

- high
- medium
- low

Final review flags:

- needs_clinician_review
- needs_billing_review
- contains_unsupported_claims
- missing_critical_details

## Final Output Shape

```json
{
  "transcript_id": "sample-001",
  "soap_note": {},
  "verification_report": {},
  "billing_suggestions": [],
  "overall_confidence": "medium",
  "review_flags": [
    "needs_clinician_review",
    "needs_billing_review"
  ]
}
```

