from __future__ import annotations

import unittest

from certinote.intake import build_follow_up_questions
from certinote.pipeline import (
    Transcript,
    TranscriptTurn,
    extract_symptom_findings,
    load_condition_rules,
    run_pipeline_for_transcript,
)


RULES = load_condition_rules()


def transcript_from_patient_turns(*texts: str) -> Transcript:
    turns = []
    for index, text in enumerate(texts, start=1):
        turns.append(TranscriptTurn(turn_id=f"t{index}", speaker="patient", text=text))
    return Transcript(
        transcript_id="test-transcript",
        source_type="demo",
        metadata={"input_mode": "test"},
        turns=turns,
    )


class CertinotePipelineTests(unittest.TestCase):
    def test_matches_condition_when_required_symptoms_are_present(self) -> None:
        transcript = transcript_from_patient_turns("I have a sore throat and fever.", "No cough.")

        report = run_pipeline_for_transcript(transcript)

        self.assertEqual(report["condition_matches"][0]["condition_id"], "possible_strep_like_pharyngitis")
        self.assertEqual(report["overall_confidence"], "medium")
        self.assertNotIn("insufficient_evidence", report["review_flags"])

    def test_returns_insufficient_evidence_when_no_rule_fully_matches(self) -> None:
        transcript = transcript_from_patient_turns("I feel tired but do not have a fever.")

        report = run_pipeline_for_transcript(transcript)

        self.assertEqual(report["condition_matches"], [])
        self.assertEqual(report["overall_confidence"], "low")
        self.assertIn("insufficient_evidence", report["review_flags"])
        self.assertEqual(report["billing_suggestions"][0]["code"], "INSUFFICIENT_EVIDENCE")

    def test_clinician_prompts_are_not_counted_as_patient_symptoms(self) -> None:
        transcript = Transcript(
            transcript_id="doctor-prompt-test",
            source_type="demo",
            metadata={},
            turns=[
                TranscriptTurn(
                    turn_id="t1",
                    speaker="doctor",
                    text="Any fever, cough, sore throat, headache, or urinary symptoms?",
                ),
                TranscriptTurn(turn_id="t2", speaker="patient", text="No, none of those."),
            ],
        )

        report = run_pipeline_for_transcript(transcript)

        self.assertEqual(report["symptom_findings"], [])
        self.assertEqual(report["condition_matches"], [])
        self.assertIn("insufficient_evidence", report["review_flags"])

    def test_negated_required_symptom_does_not_match_positive_symptom(self) -> None:
        transcript = transcript_from_patient_turns("I don't have a fever, but I feel tired.")

        findings = extract_symptom_findings(transcript, RULES)
        found_symptoms = {finding["symptom"] for finding in findings}

        self.assertIn("fatigue", found_symptoms)
        self.assertNotIn("fever", found_symptoms)

    def test_guided_intake_asks_relevant_follow_up(self) -> None:
        turns = [
            TranscriptTurn(turn_id="t1", speaker="doctor", text="What symptoms are you experiencing today?"),
            TranscriptTurn(turn_id="t2", speaker="patient", text="I have a sore throat and fever."),
        ]
        asked_symptoms: set[str] = set()

        questions = build_follow_up_questions(turns, RULES, asked_symptoms)

        self.assertEqual(questions[0], "Do you have any cough?")

    def test_matches_sinus_symptom_pattern(self) -> None:
        transcript = transcript_from_patient_turns(
            "I have facial pressure, a stuffy nose, and a headache."
        )

        report = run_pipeline_for_transcript(transcript)

        condition_ids = {match["condition_id"] for match in report["condition_matches"]}
        self.assertIn("possible_sinus_symptom_pattern", condition_ids)

    def test_matches_reflux_symptom_pattern(self) -> None:
        transcript = transcript_from_patient_turns(
            "I have heartburn and a sour taste with acid coming up after eating."
        )

        report = run_pipeline_for_transcript(transcript)

        condition_ids = {match["condition_id"] for match in report["condition_matches"]}
        self.assertIn("possible_reflux_pattern", condition_ids)


if __name__ == "__main__":
    unittest.main()
