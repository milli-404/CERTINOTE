from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from certinote.pipeline import Transcript, TranscriptTurn, extract_symptom_findings, match_conditions


def build_follow_up_questions(
    turns: list[TranscriptTurn],
    rules: list[dict[str, Any]],
    asked_symptoms: set[str],
) -> list[str]:
    transcript = build_transcript(turns)
    findings = extract_symptom_findings(transcript, rules)
    found_symptoms = {finding["symptom"] for finding in findings}
    matches = match_conditions(findings, rules)

    questions = []
    if matches:
        matched_ids = {match["condition_id"] for match in matches}
        rules_to_ask = [rule for rule in rules if rule["condition_id"] in matched_ids]
        symptom_groups = [rule.get("supporting_symptoms", []) for rule in rules_to_ask]
    else:
        rules_to_ask = candidate_rules(found_symptoms, rules)
        symptom_groups = [rule["required_symptoms"] for rule in rules_to_ask]

    for symptoms in symptom_groups:
        for symptom in symptoms:
            symptom_name = symptom["name"]
            if (
                symptom_name in found_symptoms
                or symptom_name in asked_symptoms
                or counterpart_was_asked(symptom_name, asked_symptoms)
            ):
                continue
            asked_symptoms.add(symptom_name)
            questions.append(question_for_symptom(symptom_name))
            if len(questions) >= 3:
                return questions
    return questions


def candidate_rules(found_symptoms: set[str], rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    positive_symptoms = {symptom for symptom in found_symptoms if not symptom.startswith("no ")}
    candidates = []
    for rule in rules:
        rule_symptoms = {
            symptom["name"]
            for symptom in rule["required_symptoms"] + rule.get("supporting_symptoms", [])
        }
        if positive_symptoms & rule_symptoms:
            candidates.append(rule)
    return candidates


def counterpart_was_asked(symptom_name: str, asked_symptoms: set[str]) -> bool:
    if symptom_name.startswith("no "):
        return symptom_name.removeprefix("no ") in asked_symptoms
    return f"no {symptom_name}" in asked_symptoms


def question_for_symptom(symptom_name: str) -> str:
    question_map = {
        "sore throat": "Do you have a sore throat?",
        "fever": "Do you have a fever or high temperature?",
        "no cough": "Do you have any cough?",
        "cough": "Do you have a cough?",
        "mild cough": "Is the cough mild or slight?",
        "cough at night": "Is the cough worse at night?",
        "body aches": "Do you have body aches or muscle aches?",
        "fatigue": "Do you feel unusually tired or weak?",
        "chills": "Do you have chills or shivering?",
        "loss of taste or smell": "Have you lost your sense of taste or smell?",
        "shortness of breath": "Do you have shortness of breath or trouble breathing?",
        "runny nose": "Do you have a runny nose?",
        "nasal congestion": "Do you have nasal congestion or a stuffy nose?",
        "sneezing": "Are you sneezing?",
        "itchy eyes": "Do your eyes feel itchy?",
        "watery eyes": "Are your eyes watery or tearing?",
        "facial pressure": "Do you feel pressure around your face or sinuses?",
        "thick nasal discharge": "Do you have thick or colored nasal discharge?",
        "postnasal drip": "Do you feel mucus dripping into your throat?",
        "reduced smell": "Has your sense of smell reduced?",
        "headache": "Do you have a headache?",
        "nausea": "Do you have nausea?",
        "no nausea": "Do you have nausea?",
        "light sensitivity": "Are you sensitive to light?",
        "sound sensitivity": "Are you sensitive to sound?",
        "one-sided headache": "Is the headache mostly on one side?",
        "neck tightness": "Do you have neck tightness or tension?",
        "pressure-like head pain": "Does the headache feel like pressure or a tight band?",
        "stress": "Have you been under unusual stress?",
        "burning urination": "Do you have burning or pain when urinating?",
        "frequent urination": "Are you urinating more often than usual?",
        "urgent urination": "Do you feel a sudden urgent need to urinate?",
        "lower abdominal pain": "Do you have lower abdominal or lower belly pain?",
        "cloudy urine": "Have you noticed cloudy urine?",
        "diarrhea": "Do you have diarrhea or loose stools?",
        "vomiting": "Have you been vomiting?",
        "abdominal cramps": "Do you have abdominal or stomach cramps?",
        "dehydration concern": "Do you feel dehydrated, very thirsty, or are you urinating less?",
        "heartburn": "Do you have heartburn or burning in the chest?",
        "acid regurgitation": "Do you feel acid or food coming back up?",
        "worse after meals": "Are the symptoms worse after meals?",
        "sour taste": "Do you notice a sour or bitter taste?",
        "burping": "Are you burping or belching more than usual?",
        "wheezing": "Do you have wheezing or a whistling sound when breathing?",
        "chest tightness": "Does your chest feel tight?",
        "exercise trigger": "Does exercise make the breathing symptoms worse?",
        "eye redness": "Do you have red eyes?",
        "eye discharge": "Do you have eye discharge, crusting, or stickiness?",
        "eye irritation": "Do your eyes feel gritty or irritated?",
        "ear pain": "Do you have ear pain?",
        "muffled hearing": "Does your hearing feel muffled or reduced?",
        "ear fullness": "Does the ear feel full or blocked?",
        "dizziness": "Do you feel dizzy or have vertigo?",
        "painful swallowing": "Does it hurt to swallow?",
        "swollen neck glands": "Do you have swollen or tender glands in your neck?",
    }
    return question_map.get(symptom_name, f"Do you have {symptom_name}?")


def build_transcript(turns: list[TranscriptTurn]) -> Transcript:
    return Transcript(
        transcript_id=f"live-intake-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}",
        source_type="demo",
        metadata={"input_mode": "guided_patient_intake"},
        turns=turns,
    )


def transcript_to_dict(transcript: Transcript) -> dict[str, Any]:
    return {
        "id": transcript.transcript_id,
        "source_type": transcript.source_type,
        "metadata": transcript.metadata,
        "turns": [
            {
                "turn_id": turn.turn_id,
                "speaker": turn.speaker,
                "text": turn.text,
            }
            for turn in transcript.turns
        ],
    }


def turns_from_payload(raw_turns: list[dict[str, str]]) -> list[TranscriptTurn]:
    turns = []
    for index, turn in enumerate(raw_turns, start=1):
        speaker = turn.get("speaker", "patient")
        text = turn.get("text", "")
        turns.append(TranscriptTurn(turn_id=f"t{index}", speaker=speaker, text=text))
    return turns
