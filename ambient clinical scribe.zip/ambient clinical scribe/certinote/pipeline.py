from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RULES_PATH = PROJECT_ROOT / "data" / "disease_rules" / "demo_conditions.json"


@dataclass(frozen=True)
class TranscriptTurn:
    turn_id: str
    speaker: str
    text: str


@dataclass(frozen=True)
class Transcript:
    transcript_id: str
    source_type: str
    metadata: dict[str, Any]
    turns: list[TranscriptTurn]


def load_transcript(path: Path) -> Transcript:
    raw = json.loads(path.read_text(encoding="utf-8"))
    return transcript_from_dict(raw)


def transcript_from_dict(raw: dict[str, Any]) -> Transcript:
    return Transcript(
        transcript_id=raw["id"],
        source_type=raw["source_type"],
        metadata=raw.get("metadata", {}),
        turns=[
            TranscriptTurn(
                turn_id=turn["turn_id"],
                speaker=turn["speaker"],
                text=turn["text"],
            )
            for turn in raw["turns"]
        ],
    )


def load_condition_rules(path: Path = DEFAULT_RULES_PATH) -> list[dict[str, Any]]:
    return json.loads(path.read_text(encoding="utf-8"))["conditions"]


def generate_soap_note(transcript: Transcript, rules: list[dict[str, Any]]) -> dict[str, Any]:
    symptom_findings = extract_symptom_findings(transcript, rules)
    condition_matches = match_conditions(symptom_findings, rules)

    subjective = build_subjective_section(symptom_findings)
    if condition_matches:
        matched_names = ", ".join(match["condition_name"] for match in condition_matches)
        assessment_text = (
            f"Configured symptom rules match: {matched_names}. "
            "This is not a confirmed diagnosis and requires clinician review."
        )
        assessment_confidence = "medium"
    else:
        assessment_text = "Insufficient evidence to match a condition from the configured symptom rules."
        assessment_confidence = "low"

    if condition_matches:
        plan_text = "Clinician should review the matched symptoms, perform relevant examination, and order confirmatory tests when appropriate."
    else:
        plan_text = "Collect additional history, objective findings, and clinician assessment before suggesting a condition."

    return {
        "transcript_id": transcript.transcript_id,
        "sections": {
            "subjective": {
                "text": subjective,
                "confidence": "high" if symptom_findings else "low",
                "review_required": False,
            },
            "objective": {
                "text": "No objective exam findings or vital signs documented in the transcript.",
                "confidence": "high",
                "review_required": False,
            },
            "assessment": {
                "text": assessment_text,
                "confidence": assessment_confidence,
                "review_required": True,
            },
            "plan": {
                "text": plan_text,
                "confidence": "medium" if condition_matches else "low",
                "review_required": True,
            },
        },
    }


def extract_symptom_findings(transcript: Transcript, rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    symptom_index = build_symptom_index(rules)
    findings = []

    for symptom_name, aliases in symptom_index.items():
        evidence_turn_ids = []
        matched_aliases = []
        for turn in transcript.turns:
            if turn.speaker not in {"patient", "caregiver"}:
                continue
            turn_text = turn.text.lower()
            for alias in aliases:
                if alias_is_present(alias, turn_text, symptom_name):
                    evidence_turn_ids.append(turn.turn_id)
                    matched_aliases.append(alias)
                    break

        if evidence_turn_ids:
            findings.append(
                {
                    "symptom": symptom_name,
                    "evidence_turn_ids": sorted(set(evidence_turn_ids)),
                    "matched_aliases": sorted(set(matched_aliases)),
                }
            )

    return findings


def alias_is_present(alias: str, turn_text: str, symptom_name: str) -> bool:
    alias_text = alias.lower()
    if not phrase_is_present(alias_text, turn_text):
        return False

    if symptom_name.startswith("no "):
        return True

    negation_pattern = re.compile(
        rf"\b(no|denies|denied|without|do not have|don't have|does not have|doesn't have|not having)\s+"
        rf"(a|an|any)?\s*{phrase_pattern(alias_text)}\b"
    )
    return not bool(negation_pattern.search(turn_text))


def phrase_is_present(phrase: str, text: str) -> bool:
    return bool(re.search(rf"\b{phrase_pattern(phrase)}\b", text))


def phrase_pattern(phrase: str) -> str:
    escaped_words = [re.escape(word) for word in phrase.split()]
    return r"\s+".join(escaped_words)


def build_symptom_index(rules: list[dict[str, Any]]) -> dict[str, list[str]]:
    symptom_index: dict[str, list[str]] = {}
    for rule in rules:
        for symptom in rule["required_symptoms"] + rule.get("supporting_symptoms", []):
            aliases = symptom_index.setdefault(symptom["name"], [])
            aliases.extend(symptom["aliases"])
    return {name: sorted(set(aliases)) for name, aliases in symptom_index.items()}


def match_conditions(symptom_findings: list[dict[str, Any]], rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    found_symptoms = {finding["symptom"] for finding in symptom_findings}
    matches = []

    for rule in rules:
        required_names = [symptom["name"] for symptom in rule["required_symptoms"]]
        missing_required = [name for name in required_names if name not in found_symptoms]
        if missing_required:
            continue

        evidence_turn_ids = sorted(
            {
                turn_id
                for finding in symptom_findings
                if finding["symptom"] in required_names
                for turn_id in finding["evidence_turn_ids"]
            }
        )
        matches.append(
            {
                "condition_id": rule["condition_id"],
                "condition_name": rule["condition_name"],
                "matched_required_symptoms": required_names,
                "evidence_turn_ids": evidence_turn_ids,
                "confidence": "medium",
                "requires_clinician_review": True,
                "rationale": "All required symptoms for this configured rule were found in the transcript.",
            }
        )

    return matches


def build_subjective_section(symptom_findings: list[dict[str, Any]]) -> str:
    if not symptom_findings:
        return "No configured symptoms were documented in the transcript."

    phrases = []
    for finding in symptom_findings:
        symptom = finding["symptom"]
        if symptom.startswith("no "):
            phrases.append(f"Patient denies {symptom.removeprefix('no ')}")
        else:
            phrases.append(f"Patient reports {symptom}")
    return ". ".join(phrases) + "."


def verify_soap_note(
    transcript: Transcript,
    soap_note: dict[str, Any],
    symptom_findings: list[dict[str, Any]],
    condition_matches: list[dict[str, Any]],
) -> dict[str, Any]:
    checks = []

    for index, finding in enumerate(symptom_findings, start=1):
        checks.append(
            {
                "claim_id": f"symptom-{index}",
                "section": "subjective",
                "claim": f"Transcript documents symptom: {finding['symptom']}.",
                "support_status": "supported",
                "confidence": 0.96,
                "evidence_turn_ids": finding["evidence_turn_ids"],
                "explanation": "The symptom phrase or a configured alias appears in the transcript.",
            }
        )

    if condition_matches:
        for index, match in enumerate(condition_matches, start=1):
            checks.append(
                {
                    "claim_id": f"condition-{index}",
                    "section": "assessment",
                    "claim": f"Configured rule matches {match['condition_name']}.",
                    "support_status": "partially_supported",
                    "confidence": 0.68,
                    "evidence_turn_ids": match["evidence_turn_ids"],
                    "explanation": "All required symptoms for the rule were found, but this is not a confirmed diagnosis.",
                }
            )
    else:
        checks.append(
            {
                "claim_id": "condition-insufficient-evidence",
                "section": "assessment",
                "claim": "Insufficient evidence to match a configured condition.",
                "support_status": "supported",
                "confidence": 0.92,
                "evidence_turn_ids": sorted(
                    {turn_id for finding in symptom_findings for turn_id in finding["evidence_turn_ids"]}
                ),
                "explanation": "No configured condition had all required symptoms present in the transcript.",
            }
        )

    uncertain = [check for check in checks if check["support_status"] in {"partially_supported", "uncertain"}]

    return {
        "transcript_id": transcript.transcript_id,
        "claim_checks": checks,
        "missing_details": find_missing_details(transcript, soap_note),
        "summary": {
            "overall_confidence": "medium" if condition_matches else "low",
            "review_flags": build_review_flags(unsupported=[], uncertain=uncertain, matched=bool(condition_matches)),
        },
    }


def find_missing_details(transcript: Transcript, soap_note: dict[str, Any]) -> list[dict[str, Any]]:
    note_text = json.dumps(soap_note).lower()
    missing = []

    if transcript_contains(transcript, ["allergic to penicillin", "penicillin allergy"]) and "penicillin" not in note_text:
        missing.append(
            {
                "detail": "Patient reports penicillin allergy.",
                "evidence_turn_ids": find_evidence_turn_ids(transcript, ["penicillin"]),
                "importance": "high",
            }
        )

    return missing


def transcript_contains(transcript: Transcript, terms: list[str]) -> bool:
    return bool(find_evidence_turn_ids(transcript, terms))


def find_evidence_turn_ids(transcript: Transcript, terms: list[str]) -> list[str]:
    matches = []
    for turn in transcript.turns:
        text = turn.text.lower()
        if any(term.lower() in text for term in terms):
            matches.append(turn.turn_id)
    return matches


def suggest_billing_codes(condition_matches: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not condition_matches:
        return [
            {
                "code_system": "demo",
                "code": "INSUFFICIENT_EVIDENCE",
                "description": "Insufficient evidence to suggest a diagnosis or billing concept",
                "confidence": "low",
                "evidence_turn_ids": [],
                "requires_human_review": True,
            }
        ]

    return [
        {
            "code_system": "demo",
            "code": f"DEMO_{match['condition_id'].upper()}",
            "description": f"Prototype-only billing concept for {match['condition_name']}",
            "confidence": match["confidence"],
            "evidence_turn_ids": match["evidence_turn_ids"],
            "requires_human_review": True,
        }
        for match in condition_matches
    ]


def build_review_flags(
    unsupported: list[dict[str, Any]],
    uncertain: list[dict[str, Any]],
    matched: bool,
) -> list[str]:
    flags = ["needs_clinician_review", "needs_billing_review"]
    if unsupported:
        flags.append("contains_unsupported_claims")
    if uncertain:
        flags.append("contains_uncertain_claims")
    if not matched:
        flags.append("insufficient_evidence")
    return flags


def run_pipeline(transcript_path: Path, rules_path: Path = DEFAULT_RULES_PATH) -> dict[str, Any]:
    return run_pipeline_for_transcript(load_transcript(transcript_path), rules_path=rules_path)


def run_pipeline_for_transcript(
    transcript: Transcript,
    rules_path: Path = DEFAULT_RULES_PATH,
) -> dict[str, Any]:
    rules = load_condition_rules(rules_path)
    symptom_findings = extract_symptom_findings(transcript, rules)
    condition_matches = match_conditions(symptom_findings, rules)
    soap_note = generate_soap_note(transcript, rules)
    verification_report = verify_soap_note(transcript, soap_note, symptom_findings, condition_matches)
    billing_suggestions = suggest_billing_codes(condition_matches)

    return {
        "transcript_id": transcript.transcript_id,
        "symptom_findings": symptom_findings,
        "condition_matches": condition_matches,
        "soap_note": soap_note,
        "verification_report": verification_report,
        "billing_suggestions": billing_suggestions,
        "overall_confidence": verification_report["summary"]["overall_confidence"],
        "review_flags": verification_report["summary"]["review_flags"],
    }
